#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#define WIDTH 500
#define HEIGHT 500